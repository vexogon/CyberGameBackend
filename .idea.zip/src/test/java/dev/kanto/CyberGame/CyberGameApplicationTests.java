package dev.kanto.CyberGame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CyberGameApplicationTests {

	@Test
	void contextLoads() {
	}

}
