package dev.kanto.CyberGame;

import dev.kanto.CyberGame.model.Question;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface DatabaseRepository extends ReactiveMongoRepository<Question, String> {
    List<Question> findById(@Param("id") int ID);
}
