package dev.kanto.CyberGame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CyberGameApplication {

	public static void main(String[] args) {
		SpringApplication.run(CyberGameApplication.class, args);
	}

}
